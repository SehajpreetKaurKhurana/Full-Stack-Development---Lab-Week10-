import logo from './logo.svg';
import './App.css';
import DataEntry from './DataEntry';

function App() {
  return (
    <div className="App">
      <DataEntry/>
        
      
    </div>
  );
}

export default App;
